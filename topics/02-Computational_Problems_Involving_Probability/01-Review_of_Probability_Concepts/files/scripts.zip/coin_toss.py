
import numpy as np
import numpy.random as rnd

# calculation
def run_trials(throws):
    return rnd.choice([0,1], size=throws).sum() / throws

# output 
print('%7s \t %s\n' % ('n', 'Pr(H)') + "="*25)
for n in [1, 10, 100, 1000, 10000]:
    print('%7d \t %.5f' % (n, run_trials(n)))
