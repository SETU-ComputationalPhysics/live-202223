import numpy as np
import numpy.random as rnd

# calculation
def count_multiple_of_three(throws):
    die = range(1,7)
    return ((rnd.choice(die, size=throws) % 3)==0).sum() / throws

# output 
print('%7s \t %s\n' % ('n', 'Pr(multiple of 3)') + "="*30)
for n in [10**k for k in range(1,6)]:
    print('%7d \t %.5f' % (n, count_multiple_of_three(n)))
