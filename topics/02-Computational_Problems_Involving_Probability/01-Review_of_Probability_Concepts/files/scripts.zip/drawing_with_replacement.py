import numpy as np
import numpy.random as rnd

urn = [0]*7 + [1]* 3

def trial():
    success = rnd.choice(urn, size=2).sum()==2
    return success

def trials(n):
    return sum([trial() for t in range(n)]) / n

# output 
print('%7s \t %s\n' % ('n', 'Pr(E)') + "="*25)
for n in [10**k for k in range(1,7)]:
    print('%7d \t %.5f' % (n, trials(n)))
